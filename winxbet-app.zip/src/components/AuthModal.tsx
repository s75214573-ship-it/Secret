import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { 
  UserCheck, 
  ShieldCheck, 
  Sparkles, 
  Phone, 
  Lock, 
  Eye, 
  EyeOff, 
  MessageSquare, 
  KeyRound, 
  Check, 
  ArrowRight,
  X,
  Zap,
  Gift
} from 'lucide-react';
import { triggerHaptic } from '../utils/haptics';
import { BotCaptcha } from './BotCaptcha';
import confetti from 'canvas-confetti';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultTab?: 'otp' | 'pass' | 'register';
}

export const AuthModal: React.FC<AuthModalProps> = ({ 
  isOpen, 
  onClose,
  defaultTab = 'otp'
}) => {
  const { 
    loginWithPhone, 
    registerWithPhoneOtp, 
    loginWithPhoneOtp, 
    sendPhoneOtp, 
    loginWithGoogle, 
    loginAsGuest 
  } = useAuth();

  const [tab, setTab] = useState<'otp' | 'pass' | 'register'>(defaultTab);
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [otpCode, setOtpCode] = useState('');
  const [referralCode, setReferralCode] = useState('WINXBETVIP');
  const [showPassword, setShowPassword] = useState(false);
  const [agreeTerms, setAgreeTerms] = useState(true);

  // Anti-bot captcha
  const [captchaInput, setCaptchaInput] = useState('');
  const [isCaptchaVerified, setIsCaptchaVerified] = useState(false);

  // OTP state
  const [otpCountdown, setOtpCountdown] = useState(0);
  const [isSendingOtp, setIsSendingOtp] = useState(false);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successInfo, setSuccessInfo] = useState<string | null>(null);

  const otpTimerRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (otpCountdown > 0) {
      otpTimerRef.current = setTimeout(() => {
        setOtpCountdown(prev => prev - 1);
      }, 1000);
    }
    return () => {
      if (otpTimerRef.current) clearTimeout(otpTimerRef.current);
    };
  }, [otpCountdown]);

  if (!isOpen) return null;

  const handleSendOtp = async (purpose: 'login' | 'register') => {
    setError(null);
    setSuccessInfo(null);
    const cleanDigits = phone.replace(/\D/g, '');

    if (cleanDigits.length !== 10) {
      setError('Please enter a valid 10-digit mobile number.');
      triggerHaptic('error');
      return;
    }

    if (!isCaptchaVerified) {
      setError('Please complete the Anti-Bot Security Captcha first.');
      triggerHaptic('error');
      return;
    }

    try {
      setIsSendingOtp(true);
      triggerHaptic('medium');
      const res = await sendPhoneOtp(cleanDigits, purpose);
      if (res.success) {
        setOtpCountdown(60);
        setSuccessInfo(res.message);
        triggerHaptic('success');
      } else {
        setError(res.message);
        triggerHaptic('error');
      }
    } catch (err: any) {
      setError(err?.message || 'Failed to dispatch OTP.');
      triggerHaptic('error');
    } finally {
      setIsSendingOtp(false);
    }
  };

  const handleOtpLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    triggerHaptic('medium');
    setError(null);
    setSuccessInfo(null);

    const cleanDigits = phone.replace(/\D/g, '');
    if (cleanDigits.length !== 10) {
      setError('Please enter a valid 10-digit mobile number.');
      triggerHaptic('error');
      return;
    }

    if (!isCaptchaVerified) {
      setError('Please complete the Anti-Bot Security Captcha.');
      triggerHaptic('error');
      return;
    }

    if (otpCode.trim().length !== 6) {
      setError('Please enter the complete 6-digit OTP code.');
      triggerHaptic('error');
      return;
    }

    try {
      setLoading(true);
      const res = await loginWithPhoneOtp(cleanDigits, otpCode.trim());
      if (res.success) {
        triggerHaptic('success');
        confetti({ particleCount: 50, spread: 60 });
        onClose();
      } else {
        setError(res.message);
        triggerHaptic('error');
      }
    } catch (err: any) {
      setError(err?.message || 'Login failed.');
      triggerHaptic('error');
    } finally {
      setLoading(false);
    }
  };

  const handlePasswordLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    triggerHaptic('medium');
    setError(null);
    setSuccessInfo(null);

    const cleanDigits = phone.replace(/\D/g, '');
    if (cleanDigits.length !== 10) {
      setError('Please enter your 10-digit registered mobile number.');
      triggerHaptic('error');
      return;
    }

    if (!password) {
      setError('Please enter your account password.');
      triggerHaptic('error');
      return;
    }

    if (!isCaptchaVerified) {
      setError('Please complete the Anti-Bot Security Captcha.');
      triggerHaptic('error');
      return;
    }

    try {
      setLoading(true);
      const res = await loginWithPhone(cleanDigits, password);
      if (res.success) {
        triggerHaptic('success');
        onClose();
      } else {
        setError(res.message);
        triggerHaptic('error');
      }
    } catch (err: any) {
      setError(err?.message || 'Login failed.');
      triggerHaptic('error');
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    triggerHaptic('heavy');
    setError(null);
    setSuccessInfo(null);

    const cleanDigits = phone.replace(/\D/g, '');
    if (cleanDigits.length !== 10) {
      setError('Please enter a valid 10-digit mobile number.');
      triggerHaptic('error');
      return;
    }

    if (!isCaptchaVerified) {
      setError('Please complete the Anti-Bot Security Captcha.');
      triggerHaptic('error');
      return;
    }

    if (otpCode.trim().length !== 6) {
      setError('Please enter the 6-digit OTP verification code.');
      triggerHaptic('error');
      return;
    }

    if (password.length < 6) {
      setError('Password must be at least 6 characters.');
      triggerHaptic('error');
      return;
    }

    if (password !== confirmPassword) {
      setError('Passwords do not match.');
      triggerHaptic('error');
      return;
    }

    if (!agreeTerms) {
      setError('Please accept the User Agreement and confirm 18+.');
      triggerHaptic('error');
      return;
    }

    try {
      setLoading(true);
      const res = await registerWithPhoneOtp(cleanDigits, otpCode.trim(), password, referralCode);
      if (res.success) {
        triggerHaptic('success');
        confetti({ particleCount: 80, spread: 70 });
        onClose();
      } else {
        setError(res.message);
        triggerHaptic('error');
      }
    } catch (err: any) {
      setError(err?.message || 'Registration failed.');
      triggerHaptic('error');
    } finally {
      setLoading(false);
    }
  };

  const handleGoogle = async () => {
    try {
      setLoading(true);
      setError(null);
      await loginWithGoogle();
      onClose();
    } catch (err: any) {
      setError(err?.message || 'Google login failed');
    } finally {
      setLoading(false);
    }
  };

  const handleGuest = async () => {
    try {
      setLoading(true);
      setError(null);
      await loginAsGuest();
      onClose();
    } catch (err: any) {
      setError(err?.message || 'Guest login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div id="auth-modal-overlay" className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md p-4 overflow-y-auto">
      <div id="auth-modal-card" className="w-full max-w-sm my-auto bg-gradient-to-b from-gray-900 via-gray-950 to-black border border-amber-500/30 rounded-3xl p-5 shadow-2xl text-white relative space-y-3.5">
        <button
          id="auth-modal-close"
          onClick={onClose}
          className="absolute top-4 right-4 p-1 rounded-xl text-gray-400 hover:text-white hover:bg-gray-800 transition"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header */}
        <div className="text-center pt-1 space-y-1">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-500 to-red-600 mb-1 shadow-lg shadow-amber-500/20">
            <Sparkles className="w-6 h-6 text-white" />
          </div>
          <h2 className="text-xl font-black tracking-wider text-white flex items-center justify-center gap-1.5">
            <span>WINXBET</span>
            <span className="text-amber-400 text-xs px-2 py-0.5 rounded-md bg-amber-400/10 border border-amber-400/30">
              VIP
            </span>
          </h2>
          <div className="inline-block px-2.5 py-0.5 bg-amber-500/10 border border-amber-500/30 rounded-full text-[10px] text-amber-300 font-bold">
            🎁 Sign up reward ₹68 credited instantly
          </div>
        </div>

        {/* Tab Selection */}
        <div className="bg-gray-900 p-1 rounded-2xl border border-gray-800 flex text-xs font-black gap-1">
          <button
            type="button"
            onClick={() => {
              triggerHaptic('light');
              setTab('otp');
              setError(null);
            }}
            className={`flex-1 py-1.5 rounded-xl transition text-[11px] ${
              tab === 'otp'
                ? 'bg-gradient-to-r from-red-600 to-amber-500 text-white shadow-md'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            OTP Login
          </button>
          <button
            type="button"
            onClick={() => {
              triggerHaptic('light');
              setTab('pass');
              setError(null);
            }}
            className={`flex-1 py-1.5 rounded-xl transition text-[11px] ${
              tab === 'pass'
                ? 'bg-gradient-to-r from-red-600 to-amber-500 text-white shadow-md'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            Password
          </button>
          <button
            type="button"
            onClick={() => {
              triggerHaptic('light');
              setTab('register');
              setError(null);
            }}
            className={`flex-1 py-1.5 rounded-xl transition text-[11px] flex items-center justify-center gap-1 ${
              tab === 'register'
                ? 'bg-gradient-to-r from-red-600 to-amber-500 text-white shadow-md'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            <span>Sign Up</span>
            <span className="px-1 py-0.2 rounded bg-black/40 text-amber-300 text-[9px]">+₹68</span>
          </button>
        </div>

        {/* Error / Success Toast */}
        {error && (
          <div className="p-2.5 rounded-xl bg-red-950/80 border border-red-500/50 text-xs text-red-200">
            {error}
          </div>
        )}
        {successInfo && (
          <div className="p-2.5 rounded-xl bg-emerald-950/80 border border-emerald-500/50 text-xs text-emerald-200">
            {successInfo}
          </div>
        )}

        {/* FORM: OTP LOGIN */}
        {tab === 'otp' && (
          <form onSubmit={handleOtpLogin} className="space-y-3">
            <div>
              <label className="text-[11px] font-bold text-gray-300 mb-1 block">
                Mobile Number
              </label>
              <div className="relative flex items-center">
                <div className="absolute left-3 flex items-center gap-1 text-gray-400 text-xs font-bold pointer-events-none">
                  <Phone className="w-3.5 h-3.5 text-amber-400" />
                  <span>+91</span>
                </div>
                <input
                  type="tel"
                  maxLength={10}
                  value={phone}
                  onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
                  placeholder="10-digit mobile"
                  className="w-full pl-16 pr-3 py-2 bg-gray-900 border border-gray-800 rounded-xl text-xs text-white placeholder-gray-500 focus:outline-none focus:border-amber-500 font-mono"
                  required
                />
              </div>
            </div>

            <BotCaptcha
              idPrefix="modal-otp"
              captchaInput={captchaInput}
              onCaptchaInputChange={setCaptchaInput}
              onVerifiedChange={setIsCaptchaVerified}
            />

            <div>
              <label className="text-[11px] font-bold text-gray-300 mb-1 block">
                6-Digit OTP Code
              </label>
              <div className="flex items-center gap-2">
                <div className="relative flex-1 flex items-center">
                  <KeyRound className="w-3.5 h-3.5 text-amber-400 absolute left-3 pointer-events-none" />
                  <input
                    type="text"
                    maxLength={6}
                    value={otpCode}
                    onChange={(e) => setOtpCode(e.target.value.replace(/\D/g, ''))}
                    placeholder="Enter OTP (bypass: 123456)"
                    className="w-full pl-9 pr-3 py-2 bg-gray-900 border border-gray-800 rounded-xl text-xs text-amber-300 font-mono font-bold tracking-widest placeholder:font-sans placeholder:tracking-normal placeholder-gray-500 focus:outline-none focus:border-amber-500"
                    required
                  />
                </div>

                <button
                  type="button"
                  disabled={isSendingOtp || otpCountdown > 0}
                  onClick={() => handleSendOtp('login')}
                  className="px-3 py-2 rounded-xl text-xs font-bold bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 shrink-0 disabled:opacity-50"
                >
                  {isSendingOtp ? 'Sending...' : otpCountdown > 0 ? `${otpCountdown}s` : 'Send OTP'}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 bg-gradient-to-r from-red-600 via-rose-600 to-amber-500 hover:from-red-500 hover:to-amber-400 text-white font-black text-xs rounded-xl shadow-lg transition active:scale-[0.99] flex items-center justify-center gap-1.5 disabled:opacity-50"
            >
              {loading ? 'Verifying...' : 'Verify OTP & Sign In'}
            </button>
          </form>
        )}

        {/* FORM: PASSWORD LOGIN */}
        {tab === 'pass' && (
          <form onSubmit={handlePasswordLogin} className="space-y-3">
            <div>
              <label className="text-[11px] font-bold text-gray-300 mb-1 block">
                Mobile Number
              </label>
              <div className="relative flex items-center">
                <div className="absolute left-3 flex items-center gap-1 text-gray-400 text-xs font-bold pointer-events-none">
                  <Phone className="w-3.5 h-3.5 text-amber-400" />
                  <span>+91</span>
                </div>
                <input
                  type="tel"
                  maxLength={10}
                  value={phone}
                  onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
                  placeholder="10-digit mobile"
                  className="w-full pl-16 pr-3 py-2 bg-gray-900 border border-gray-800 rounded-xl text-xs text-white placeholder-gray-500 focus:outline-none focus:border-amber-500 font-mono"
                  required
                />
              </div>
            </div>

            <div>
              <label className="text-[11px] font-bold text-gray-300 mb-1 block">
                Password
              </label>
              <div className="relative flex items-center">
                <Lock className="w-3.5 h-3.5 text-amber-400 absolute left-3 pointer-events-none" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Your password"
                  className="w-full pl-9 pr-10 py-2 bg-gray-900 border border-gray-800 rounded-xl text-xs text-white placeholder-gray-500 focus:outline-none focus:border-amber-500"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 text-gray-400 hover:text-white"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <BotCaptcha
              idPrefix="modal-pass"
              captchaInput={captchaInput}
              onCaptchaInputChange={setCaptchaInput}
              onVerifiedChange={setIsCaptchaVerified}
            />

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 bg-gradient-to-r from-red-600 via-rose-600 to-amber-500 hover:from-red-500 hover:to-amber-400 text-white font-black text-xs rounded-xl shadow-lg transition active:scale-[0.99] flex items-center justify-center gap-1.5 disabled:opacity-50"
            >
              {loading ? 'Logging in...' : 'Log In to WinXbet'}
            </button>
          </form>
        )}

        {/* FORM: REGISTER WITH NUMBER + OTP + BOT CAPTCHA */}
        {tab === 'register' && (
          <form onSubmit={handleRegister} className="space-y-3">
            <div>
              <label className="text-[11px] font-bold text-gray-300 mb-1 block">
                Mobile Number
              </label>
              <div className="relative flex items-center">
                <div className="absolute left-3 flex items-center gap-1 text-gray-400 text-xs font-bold pointer-events-none">
                  <Phone className="w-3.5 h-3.5 text-amber-400" />
                  <span>+91</span>
                </div>
                <input
                  type="tel"
                  maxLength={10}
                  value={phone}
                  onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
                  placeholder="10-digit mobile"
                  className="w-full pl-16 pr-3 py-2 bg-gray-900 border border-gray-800 rounded-xl text-xs text-white placeholder-gray-500 focus:outline-none focus:border-amber-500 font-mono"
                  required
                />
              </div>
            </div>

            <BotCaptcha
              idPrefix="modal-reg"
              captchaInput={captchaInput}
              onCaptchaInputChange={setCaptchaInput}
              onVerifiedChange={setIsCaptchaVerified}
            />

            <div>
              <label className="text-[11px] font-bold text-gray-300 mb-1 block">
                SMS OTP Verification
              </label>
              <div className="flex items-center gap-2">
                <div className="relative flex-1 flex items-center">
                  <KeyRound className="w-3.5 h-3.5 text-amber-400 absolute left-3 pointer-events-none" />
                  <input
                    type="text"
                    maxLength={6}
                    value={otpCode}
                    onChange={(e) => setOtpCode(e.target.value.replace(/\D/g, ''))}
                    placeholder="6-digit OTP (123456)"
                    className="w-full pl-9 pr-3 py-2 bg-gray-900 border border-gray-800 rounded-xl text-xs text-amber-300 font-mono font-bold tracking-widest placeholder:font-sans placeholder:tracking-normal placeholder-gray-500 focus:outline-none focus:border-amber-500"
                    required
                  />
                </div>

                <button
                  type="button"
                  disabled={isSendingOtp || otpCountdown > 0}
                  onClick={() => handleSendOtp('register')}
                  className="px-3 py-2 rounded-xl text-xs font-bold bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 shrink-0 disabled:opacity-50"
                >
                  {isSendingOtp ? '...' : otpCountdown > 0 ? `${otpCountdown}s` : 'Send OTP'}
                </button>
              </div>
            </div>

            <div>
              <label className="text-[11px] font-bold text-gray-300 mb-1 block">
                Create Password
              </label>
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Password (min. 6 chars)"
                className="w-full px-3 py-2 bg-gray-900 border border-gray-800 rounded-xl text-xs text-white placeholder-gray-500 focus:outline-none focus:border-amber-500"
                required
              />
            </div>

            <div>
              <label className="text-[11px] font-bold text-gray-300 mb-1 block">
                Confirm Password
              </label>
              <input
                type={showPassword ? 'text' : 'password'}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="Confirm password"
                className="w-full px-3 py-2 bg-gray-900 border border-gray-800 rounded-xl text-xs text-white placeholder-gray-500 focus:outline-none focus:border-amber-500"
                required
              />
            </div>

            <div className="flex items-start gap-2 pt-0.5">
              <input
                id="modal-terms-checkbox"
                type="checkbox"
                checked={agreeTerms}
                onChange={(e) => setAgreeTerms(e.target.checked)}
                className="mt-0.5 rounded text-amber-500 bg-gray-950 border-gray-800"
              />
              <label htmlFor="modal-terms-checkbox" className="text-[10px] text-gray-400">
                I am 18+ and accept the WinXbet VIP Terms &amp; Policy.
              </label>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 bg-gradient-to-r from-red-600 via-rose-600 to-amber-500 hover:from-red-500 hover:to-amber-400 text-white font-black text-xs rounded-xl shadow-lg transition active:scale-[0.99] flex items-center justify-center gap-1.5 disabled:opacity-50"
            >
              {loading ? 'Creating...' : 'Register & Claim ₹68 Bonus'}
            </button>
          </form>
        )}

        {/* Alternate 1-click logins */}
        <div className="pt-2 border-t border-gray-800/80 space-y-2">
          <div className="grid grid-cols-2 gap-2">
            <button
              id="google-signin-btn"
              onClick={handleGoogle}
              disabled={loading}
              className="flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-white text-gray-900 font-bold text-xs hover:bg-gray-100 transition shadow-md disabled:opacity-50"
            >
              <svg className="w-4 h-4 shrink-0" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.8-2.4 3.65v3.03h3.88c2.27-2.09 3.66-5.17 3.66-9.12z"
                />
                <path
                  fill="#34A853"
                  d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.03c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.27v3.13C3.25 21.3 7.33 24 12 24z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.28 14.29c-.25-.72-.38-1.49-.38-2.29s.13-1.57.38-2.29V6.57H1.27C.46 8.19 0 10.04 0 12s.46 3.81 1.27 5.43l4.01-3.14z"
                />
                <path
                  fill="#EA4335"
                  d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.25 2.7 1.27 6.57l4.01 3.14c.95-2.83 3.6-4.96 6.72-4.96z"
                />
              </svg>
              <span>Google</span>
            </button>

            <button
              id="guest-signin-btn"
              onClick={handleGuest}
              disabled={loading}
              className="flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-gray-900 hover:bg-gray-800 text-amber-300 font-bold text-xs border border-amber-500/20 transition disabled:opacity-50"
            >
              <UserCheck className="w-4 h-4 text-amber-400" />
              <span>Guest Play</span>
            </button>
          </div>
        </div>

        <div className="flex items-center justify-center gap-2 text-gray-500 text-[10px] pt-1">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
          <span>256-Bit Encrypted &amp; Anti-Bot Verified</span>
        </div>
      </div>
    </div>
  );
};
