import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { 
  ShieldCheck, 
  Sparkles, 
  Phone, 
  Lock, 
  Eye, 
  EyeOff, 
  Gift, 
  ArrowRight, 
  Flame, 
  CheckCircle2, 
  UserCheck,
  Award,
  ShieldAlert,
  X,
  KeyRound,
  MessageSquare,
  RotateCcw,
  Check,
  Copy,
  Download,
  Zap,
  Info
} from 'lucide-react';
import { triggerHaptic } from '../utils/haptics';
import { playClickSound, playWinSound } from '../utils/audio';
import confetti from 'canvas-confetti';
import { BotCaptcha } from './BotCaptcha';

interface SmsNotificationData {
  phone: string;
  code: string;
  purpose: 'login' | 'register';
  expiresInMinutes: number;
}

export const LoginFirstGateway: React.FC = () => {
  const { 
    loginWithPhone, 
    registerWithPhone, 
    loginWithGoogle, 
    loginAsGuest, 
    loginAsAdmin,
    sendPhoneOtp, 
    loginWithPhoneOtp, 
    registerWithPhoneOtp 
  } = useAuth();

  // Mode: 'otp-login' | 'pass-login' | 'register'
  const [mode, setMode] = useState<'otp-login' | 'pass-login' | 'register'>(() => {
    if (typeof window !== 'undefined' && sessionStorage.getItem('inactivity_logged_out') === 'true') {
      return 'pass-login';
    }
    return 'otp-login';
  });

  const [inactivityNotice, setInactivityNotice] = useState<string | null>(() => {
    if (typeof window !== 'undefined') {
      const isLoggedOut = sessionStorage.getItem('inactivity_logged_out');
      const logoutTime = sessionStorage.getItem('inactivity_logout_time');
      if (isLoggedOut === 'true') {
        return logoutTime 
          ? `Your VIP session was automatically logged out at ${logoutTime} after 15 minutes of inactivity for your account & wallet security.`
          : 'Your VIP session was automatically logged out after 15 minutes of inactivity for your account & wallet security.';
      }
    }
    return null;
  });

  const dismissInactivityNotice = () => {
    sessionStorage.removeItem('inactivity_logged_out');
    sessionStorage.removeItem('inactivity_logout_time');
    setInactivityNotice(null);
  };

  // Form Fields
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [otpCode, setOtpCode] = useState('');
  const [referralCode, setReferralCode] = useState('WINXBETVIP');
  const [showPassword, setShowPassword] = useState(false);
  const [agreeTerms, setAgreeTerms] = useState(true);

  // Anti-bot Captcha state
  const [captchaInput, setCaptchaInput] = useState('');
  const [isCaptchaVerified, setIsCaptchaVerified] = useState(false);

  // OTP cooldown timer state
  const [otpCountdown, setOtpCountdown] = useState<number>(0);
  const [isSendingOtp, setIsSendingOtp] = useState<boolean>(false);
  const [activeSmsNotification, setActiveSmsNotification] = useState<SmsNotificationData | null>(null);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successInfo, setSuccessInfo] = useState<string | null>(null);

  const otpTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Listen to simulated VIP SMS event
  useEffect(() => {
    const handleSmsEvent = (e: any) => {
      if (e?.detail) {
        setActiveSmsNotification(e.detail);
        triggerHaptic('success');
        playWinSound();
      }
    };
    window.addEventListener('winxbet_otp_sms', handleSmsEvent);
    return () => window.removeEventListener('winxbet_otp_sms', handleSmsEvent);
  }, []);

  // OTP Countdown countdown tick
  useEffect(() => {
    if (otpCountdown > 0) {
      otpTimerRef.current = setTimeout(() => {
        setOtpCountdown(prev => prev - 1);
      }, 1000);
    }
    return () => {
      if (otpTimerRef.current) clearTimeout(otpTimerRef.current);
    };
  }, [otpCountdown]);

  // Request SMS OTP code
  const handleSendOtp = async (purpose: 'login' | 'register') => {
    setError(null);
    setSuccessInfo(null);
    const cleanPhone = phone.replace(/\D/g, '');

    if (cleanPhone.length !== 10) {
      setError('Please enter a valid 10-digit mobile number before requesting OTP.');
      triggerHaptic('error');
      return;
    }

    if (!isCaptchaVerified) {
      setError('Please complete the Anti-Bot Security Captcha first.');
      triggerHaptic('error');
      return;
    }

    try {
      setIsSendingOtp(true);
      triggerHaptic('medium');
      const res = await sendPhoneOtp(cleanPhone, purpose);
      if (res.success) {
        setOtpCountdown(60);
        setSuccessInfo(res.message);
        triggerHaptic('success');
      } else {
        setError(res.message);
        triggerHaptic('error');
      }
    } catch (err: any) {
      setError(err?.message || 'Failed to dispatch OTP. Please try again.');
      triggerHaptic('error');
    } finally {
      setIsSendingOtp(false);
    }
  };

  // 1-Click Auto Fill received OTP
  const handleAutoFillOtp = (code: string) => {
    triggerHaptic('selection');
    setOtpCode(code);
    setActiveSmsNotification(null);
    setSuccessInfo(`OTP ${code} auto-filled! You can now verify and proceed.`);
  };

  // Submit Handler for OTP-based Login
  const handleOtpLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    triggerHaptic('medium');
    setError(null);
    setSuccessInfo(null);

    const cleanPhone = phone.replace(/\D/g, '');
    if (cleanPhone.length !== 10) {
      setError('Please enter a valid 10-digit mobile number.');
      triggerHaptic('error');
      return;
    }

    if (otpCode.trim().length !== 6) {
      setError('Please enter the complete 6-digit OTP code.');
      triggerHaptic('error');
      return;
    }

    if (!isCaptchaVerified) {
      setError('Please complete the Anti-Bot Security Captcha.');
      triggerHaptic('error');
      return;
    }

    try {
      setLoading(true);
      const res = await loginWithPhoneOtp(cleanPhone, otpCode.trim());
      if (!res.success) {
        setError(res.message);
        triggerHaptic('error');
      } else {
        triggerHaptic('success');
        confetti({ particleCount: 60, spread: 60 });
      }
    } catch (err: any) {
      setError(err?.message || 'Login failed. Please try again.');
      triggerHaptic('error');
    } finally {
      setLoading(false);
    }
  };

  // Submit Handler for Password-based Login
  const handlePasswordLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    triggerHaptic('medium');
    setError(null);
    setSuccessInfo(null);

    const cleanPhone = phone.replace(/\D/g, '');
    if (cleanPhone.length !== 10) {
      setError('Please enter your 10-digit registered mobile number.');
      triggerHaptic('error');
      return;
    }

    if (!password) {
      setError('Please enter your account password.');
      triggerHaptic('error');
      return;
    }

    if (!isCaptchaVerified) {
      setError('Please complete the Anti-Bot Security Captcha.');
      triggerHaptic('error');
      return;
    }

    try {
      setLoading(true);
      const res = await loginWithPhone(cleanPhone, password);
      if (!res.success) {
        setError(res.message);
        triggerHaptic('error');
      } else {
        triggerHaptic('success');
      }
    } catch (err: any) {
      setError(err?.message || 'Login failed. Please check credentials.');
      triggerHaptic('error');
    } finally {
      setLoading(false);
    }
  };

  // Submit Handler for VIP Registration
  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    triggerHaptic('heavy');
    setError(null);
    setSuccessInfo(null);

    const cleanPhone = phone.replace(/\D/g, '');
    if (cleanPhone.length !== 10) {
      setError('Please enter a valid 10-digit mobile number.');
      triggerHaptic('error');
      return;
    }

    if (!isCaptchaVerified) {
      setError('Please complete the Anti-Bot Security Captcha.');
      triggerHaptic('error');
      return;
    }

    if (otpCode.trim().length !== 6) {
      setError('Please enter the 6-digit OTP verification code.');
      triggerHaptic('error');
      return;
    }

    if (password.length < 6) {
      setError('Password must be at least 6 characters.');
      triggerHaptic('error');
      return;
    }

    if (password !== confirmPassword) {
      setError('Passwords do not match. Please re-check.');
      triggerHaptic('error');
      return;
    }

    if (!agreeTerms) {
      setError('Please accept the User Agreement and confirm 18+ declaration.');
      triggerHaptic('error');
      return;
    }

    try {
      setLoading(true);
      const res = await registerWithPhoneOtp(cleanPhone, otpCode.trim(), password, referralCode);
      if (!res.success) {
        setError(res.message);
        triggerHaptic('error');
      } else {
        triggerHaptic('success');
        confetti({ particleCount: 100, spread: 80, origin: { y: 0.6 } });
      }
    } catch (err: any) {
      setError(err?.message || 'Registration failed. Please try again.');
      triggerHaptic('error');
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleAuth = async () => {
    try {
      triggerHaptic('medium');
      setLoading(true);
      setError(null);
      await loginWithGoogle();
      triggerHaptic('success');
    } catch (err: any) {
      setError(err?.message || 'Google sign-in failed');
      triggerHaptic('error');
    } finally {
      setLoading(false);
    }
  };

  const handleGuestAuth = async () => {
    try {
      triggerHaptic('medium');
      setLoading(true);
      setError(null);
      await loginAsGuest();
      triggerHaptic('success');
      confetti({ particleCount: 70, spread: 60 });
    } catch (err: any) {
      setError(err?.message || 'Guest access failed');
      triggerHaptic('error');
    } finally {
      setLoading(false);
    }
  };

  const handleAdminAuth = async () => {
    try {
      triggerHaptic('heavy');
      setLoading(true);
      setError(null);
      await loginAsAdmin();
      triggerHaptic('success');
    } catch (err: any) {
      setError(err?.message || 'Admin login failed');
      triggerHaptic('error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div id="login-gateway-container" className="w-full max-w-md mx-auto min-h-screen bg-gray-950 text-gray-100 flex flex-col justify-between p-4 shadow-2xl relative">
      {/* Background Ambience Glows */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-80 h-80 bg-red-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 right-0 w-60 h-60 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Realistic Simulated VIP SMS Popup Notification */}
      {activeSmsNotification && (
        <div 
          id="vip-sms-notification-card"
          className="fixed top-4 left-4 right-4 max-w-sm mx-auto z-50 p-3.5 rounded-2xl bg-gradient-to-r from-gray-900 via-slate-900 to-gray-900 border border-amber-400/60 shadow-2xl shadow-black/80 flex items-start gap-3 animate-in slide-in-from-top duration-300 ring-2 ring-amber-400/20"
        >
          <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-400/40 flex items-center justify-center shrink-0 text-amber-400 mt-0.5">
            <MessageSquare className="w-5 h-5" />
          </div>
          <div className="flex-1 space-y-1">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-black text-amber-300 uppercase tracking-wider flex items-center gap-1">
                <span>VIP SMS Gateway</span>
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              </span>
              <button
                type="button"
                onClick={() => setActiveSmsNotification(null)}
                className="text-gray-400 hover:text-white p-0.5"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
            <p className="text-xs text-white">
              Your WinXbet verification code is <strong className="text-amber-300 font-mono text-sm tracking-wider underline decoration-amber-400">{activeSmsNotification.code}</strong>. Valid for 5m.
            </p>
            <div className="pt-1 flex items-center gap-2">
              <button
                type="button"
                onClick={() => handleAutoFillOtp(activeSmsNotification.code)}
                className="px-3 py-1 rounded-lg bg-gradient-to-r from-amber-500 to-red-500 hover:from-amber-400 hover:to-red-400 text-gray-950 font-black text-[11px] flex items-center gap-1.5 shadow-md active:scale-95 transition"
              >
                <Check className="w-3.5 h-3.5 stroke-[3]" />
                <span>Auto-Fill Code ({activeSmsNotification.code})</span>
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="relative z-10 space-y-3.5 pt-2">
        {/* Top VIP Branding Header */}
        <div className="text-center space-y-2">
          <div className="inline-flex items-center justify-center gap-2.5">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-tr from-red-600 via-rose-500 to-amber-500 flex items-center justify-center font-black text-white text-xl tracking-tighter shadow-lg shadow-red-600/30">
              WX
            </div>
            <div className="text-left">
              <div className="text-2xl font-black text-white tracking-wider flex items-center gap-1.5 leading-none">
                <span>WinXbet</span>
                <span className="text-amber-400 text-xs px-2 py-0.5 bg-amber-400/10 rounded-md border border-amber-400/30 font-extrabold">
                  VIP
                </span>
              </div>
              <div className="text-[11px] text-gray-400 font-medium mt-0.5">
                India's Trusted Color Prediction &amp; Lottery
              </div>
            </div>
          </div>

          <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-gray-900/80 border border-gray-800 rounded-full text-[11px] text-gray-300">
            <Flame className="w-3.5 h-3.5 text-amber-400 fill-amber-400 animate-pulse" />
            <span>Over 1,420,000+ Active Players Today</span>
          </div>
        </div>

        {/* Inactivity Logout Alert (if applicable) */}
        {inactivityNotice && (
          <div 
            id="inactivity-logout-alert"
            className="p-3 rounded-2xl bg-gradient-to-r from-amber-950/90 via-gray-900 to-amber-950/80 border border-amber-500/50 shadow-lg text-xs text-amber-200 flex items-start gap-3 relative animate-in fade-in duration-200"
          >
            <div className="w-7 h-7 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center shrink-0 text-amber-400 mt-0.5">
              <ShieldAlert className="w-4 h-4" />
            </div>
            <div className="flex-1 space-y-0.5 pr-5">
              <div className="font-black text-amber-300 flex items-center gap-1.5 text-xs">
                <span>Security Auto-Logout</span>
                <span className="px-1.5 py-0.2 bg-amber-500/20 rounded text-[9px] font-bold">15 MINS</span>
              </div>
              <p className="text-[11px] text-gray-300 leading-snug">
                {inactivityNotice}
              </p>
            </div>
            <button
              id="dismiss-inactivity-notice-btn"
              type="button"
              onClick={dismissInactivityNotice}
              className="absolute top-2.5 right-2.5 p-1 rounded-lg hover:bg-gray-800 text-gray-400 hover:text-white transition"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Registration ₹68 Bonus Promo Banner */}
        <div className="relative overflow-hidden bg-gradient-to-r from-red-700 via-rose-600 to-amber-600 rounded-2xl p-3.5 text-white shadow-xl border border-red-500/30">
          <div className="absolute -right-4 -top-4 w-24 h-24 bg-white/10 rounded-full blur-xl pointer-events-none" />
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center shrink-0 border border-white/30 shadow-inner">
              <Gift className="w-6 h-6 text-amber-200 animate-bounce" />
            </div>
            <div className="space-y-0.5 flex-1">
              <div className="inline-flex items-center gap-1 text-[10px] font-black uppercase tracking-wider text-amber-200">
                <Sparkles className="w-3 h-3" />
                <span>New Member Exclusive</span>
              </div>
              <h3 className="text-base font-black leading-tight tracking-tight">
                Sign Up &amp; Claim <span className="text-amber-300 text-lg underline decoration-amber-300 underline-offset-2">₹68 Bonus</span>
              </h3>
              <p className="text-[11px] text-white/90">
                Instant ₹68 free credit into wallet upon phone verification.
              </p>
            </div>
          </div>
        </div>

        {/* Navigation Tabs: OTP Login, Password Login, Sign Up */}
        <div className="bg-gray-900/90 p-1 rounded-2xl border border-gray-800 flex text-xs font-black gap-1 shadow-md">
          <button
            id="tab-otp-login-btn"
            type="button"
            onClick={() => {
              triggerHaptic('light');
              setMode('otp-login');
              setError(null);
              setSuccessInfo(null);
            }}
            className={`flex-1 py-2 px-1 rounded-xl transition flex items-center justify-center gap-1.5 text-center ${
              mode === 'otp-login'
                ? 'bg-gradient-to-r from-red-600 via-rose-600 to-amber-500 text-white shadow-md'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">OTP Login</span>
          </button>

          <button
            id="tab-pass-login-btn"
            type="button"
            onClick={() => {
              triggerHaptic('light');
              setMode('pass-login');
              setError(null);
              setSuccessInfo(null);
            }}
            className={`flex-1 py-2 px-1 rounded-xl transition flex items-center justify-center gap-1.5 text-center ${
              mode === 'pass-login'
                ? 'bg-gradient-to-r from-red-600 via-rose-600 to-amber-500 text-white shadow-md'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            <Lock className="w-3.5 h-3.5 shrink-0" />
            <span className="truncate">Password</span>
          </button>

          <button
            id="tab-register-btn"
            type="button"
            onClick={() => {
              triggerHaptic('light');
              setMode('register');
              setError(null);
              setSuccessInfo(null);
            }}
            className={`flex-1 py-2 px-1 rounded-xl transition flex items-center justify-center gap-1 text-center relative ${
              mode === 'register'
                ? 'bg-gradient-to-r from-red-600 via-rose-600 to-amber-500 text-white shadow-md'
                : 'text-gray-400 hover:text-white'
            }`}
          >
            <Zap className="w-3.5 h-3.5 shrink-0 text-amber-300" />
            <span className="truncate">Sign Up</span>
            <span className="px-1 py-0.2 rounded bg-black/40 text-amber-300 text-[9px] font-bold border border-amber-300/30">
              +₹68
            </span>
          </button>
        </div>

        {/* Feedback Alert Banners */}
        {error && (
          <div className="p-3 rounded-xl bg-red-950/80 border border-red-500/50 text-xs text-red-200 flex items-center gap-2 animate-shake">
            <span className="w-2 h-2 rounded-full bg-red-400 shrink-0" />
            <span className="flex-1">{error}</span>
            <button onClick={() => setError(null)} className="text-red-400 hover:text-white">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {successInfo && (
          <div className="p-3 rounded-xl bg-emerald-950/80 border border-emerald-500/50 text-xs text-emerald-200 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="flex-1">{successInfo}</span>
            <button onClick={() => setSuccessInfo(null)} className="text-emerald-400 hover:text-white">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* ---------------------------------------------------------------- */}
        {/* FORM 1: NUMBER LOGIN WITH OTP (SMS VERIFICATION) */}
        {/* ---------------------------------------------------------------- */}
        {mode === 'otp-login' && (
          <form onSubmit={handleOtpLogin} className="bg-gray-900/90 border border-gray-800/90 rounded-2xl p-4 shadow-xl space-y-3.5">
            <div>
              <label className="text-[11px] font-bold text-gray-300 mb-1.5 block">
                Registered Mobile Number
              </label>
              <div className="relative flex items-center">
                <div className="absolute left-3 flex items-center gap-1 text-gray-400 text-xs font-bold pointer-events-none">
                  <Phone className="w-3.5 h-3.5 text-amber-400" />
                  <span>+91</span>
                </div>
                <input
                  id="otp-login-phone-input"
                  type="tel"
                  maxLength={10}
                  value={phone}
                  onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
                  placeholder="Enter 10-digit mobile number"
                  className="w-full pl-16 pr-3 py-2.5 bg-gray-950 border border-gray-800 rounded-xl text-xs text-white placeholder-gray-500 focus:outline-none focus:border-amber-500 font-mono transition"
                  required
                />
              </div>
            </div>

            {/* Anti-Bot Security Captcha */}
            <BotCaptcha
              idPrefix="otp-login"
              captchaInput={captchaInput}
              onCaptchaInputChange={setCaptchaInput}
              onVerifiedChange={setIsCaptchaVerified}
            />

            {/* OTP Code & Dispatch Button */}
            <div>
              <label className="text-[11px] font-bold text-gray-300 mb-1.5 flex items-center justify-between">
                <span>6-Digit Verification Code</span>
                <span className="text-[10px] text-gray-400">Demo bypass: 123456</span>
              </label>
              <div className="flex items-center gap-2">
                <div className="relative flex-1 flex items-center">
                  <KeyRound className="w-3.5 h-3.5 text-amber-400 absolute left-3 pointer-events-none" />
                  <input
                    id="otp-login-code-input"
                    type="text"
                    maxLength={6}
                    value={otpCode}
                    onChange={(e) => setOtpCode(e.target.value.replace(/\D/g, ''))}
                    placeholder="Enter 6-digit OTP"
                    className="w-full pl-9 pr-3 py-2.5 bg-gray-950 border border-gray-800 rounded-xl text-xs text-amber-300 font-mono font-bold tracking-widest placeholder:font-sans placeholder:tracking-normal placeholder:font-normal placeholder-gray-500 focus:outline-none focus:border-amber-500 transition"
                    required
                  />
                </div>

                <button
                  id="otp-login-send-btn"
                  type="button"
                  disabled={isSendingOtp || otpCountdown > 0}
                  onClick={() => handleSendOtp('login')}
                  className="px-3.5 py-2.5 rounded-xl font-bold text-xs bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 shrink-0 transition disabled:opacity-50 disabled:pointer-events-none flex items-center gap-1"
                >
                  {isSendingOtp ? (
                    <div className="w-3.5 h-3.5 border-2 border-amber-400 border-t-transparent rounded-full animate-spin" />
                  ) : otpCountdown > 0 ? (
                    <span>{otpCountdown}s Resend</span>
                  ) : (
                    <span>Send OTP</span>
                  )}
                </button>
              </div>
            </div>

            <button
              id="submit-otp-login-btn"
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-gradient-to-r from-red-600 via-rose-600 to-amber-500 hover:from-red-500 hover:to-amber-400 text-white font-black text-sm rounded-xl shadow-lg transition active:scale-[0.99] flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <MessageSquare className="w-4 h-4" />
                  <span>Verify OTP &amp; Sign In</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>

            <div className="pt-1 text-center">
              <button
                type="button"
                onClick={() => setMode('pass-login')}
                className="text-xs text-amber-400 hover:text-amber-300 font-semibold"
              >
                Prefer password? Switch to Password Login &rarr;
              </button>
            </div>
          </form>
        )}

        {/* ---------------------------------------------------------------- */}
        {/* FORM 2: NUMBER LOGIN WITH PASSWORD */}
        {/* ---------------------------------------------------------------- */}
        {mode === 'pass-login' && (
          <form onSubmit={handlePasswordLogin} className="bg-gray-900/90 border border-gray-800/90 rounded-2xl p-4 shadow-xl space-y-3.5">
            <div>
              <label className="text-[11px] font-bold text-gray-300 mb-1.5 block">
                Mobile Phone Number
              </label>
              <div className="relative flex items-center">
                <div className="absolute left-3 flex items-center gap-1 text-gray-400 text-xs font-bold pointer-events-none">
                  <Phone className="w-3.5 h-3.5 text-amber-400" />
                  <span>+91</span>
                </div>
                <input
                  id="login-phone-input"
                  type="tel"
                  maxLength={10}
                  value={phone}
                  onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
                  placeholder="Enter 10-digit mobile number"
                  className="w-full pl-16 pr-3 py-2.5 bg-gray-950 border border-gray-800 rounded-xl text-xs text-white placeholder-gray-500 focus:outline-none focus:border-amber-500 font-mono transition"
                  required
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-[11px] font-bold text-gray-300">
                  Password
                </label>
                <button
                  type="button"
                  onClick={() => {
                    triggerHaptic('light');
                    setMode('otp-login');
                    setSuccessInfo('Switched to OTP mode. Enter your phone and verify via SMS OTP.');
                  }}
                  className="text-[11px] text-amber-400 hover:underline"
                >
                  Forgot password? Use OTP
                </button>
              </div>
              <div className="relative flex items-center">
                <Lock className="w-3.5 h-3.5 text-amber-400 absolute left-3 pointer-events-none" />
                <input
                  id="login-password-input"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  className="w-full pl-9 pr-10 py-2.5 bg-gray-950 border border-gray-800 rounded-xl text-xs text-white placeholder-gray-500 focus:outline-none focus:border-amber-500 transition"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 text-gray-400 hover:text-white"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Anti-Bot Security Captcha */}
            <BotCaptcha
              idPrefix="pass-login"
              captchaInput={captchaInput}
              onCaptchaInputChange={setCaptchaInput}
              onVerifiedChange={setIsCaptchaVerified}
            />

            <button
              id="submit-login-btn"
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-gradient-to-r from-red-600 via-rose-600 to-amber-500 hover:from-red-500 hover:to-amber-400 text-white font-black text-sm rounded-xl shadow-lg transition active:scale-[0.99] flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <span>Log In to WinXbet</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>
        )}

        {/* ---------------------------------------------------------------- */}
        {/* FORM 3: SIGN UP / REGISTER WITH NUMBER + OTP + BOT CAPTCHA */}
        {/* ---------------------------------------------------------------- */}
        {mode === 'register' && (
          <form onSubmit={handleRegister} className="bg-gray-900/90 border border-gray-800/90 rounded-2xl p-4 shadow-xl space-y-3.5">
            <div>
              <label className="text-[11px] font-bold text-gray-300 mb-1.5 block">
                Mobile Phone Number
              </label>
              <div className="relative flex items-center">
                <div className="absolute left-3 flex items-center gap-1 text-gray-400 text-xs font-bold pointer-events-none">
                  <Phone className="w-3.5 h-3.5 text-amber-400" />
                  <span>+91</span>
                </div>
                <input
                  id="register-phone-input"
                  type="tel"
                  maxLength={10}
                  value={phone}
                  onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
                  placeholder="Enter 10-digit mobile number"
                  className="w-full pl-16 pr-3 py-2.5 bg-gray-950 border border-gray-800 rounded-xl text-xs text-white placeholder-gray-500 focus:outline-none focus:border-amber-500 font-mono transition"
                  required
                />
              </div>
            </div>

            {/* Anti-Bot Security Captcha (Mandatory before OTP dispatch) */}
            <BotCaptcha
              idPrefix="register"
              captchaInput={captchaInput}
              onCaptchaInputChange={setCaptchaInput}
              onVerifiedChange={setIsCaptchaVerified}
            />

            {/* OTP Verification Input & Send Button */}
            <div>
              <label className="text-[11px] font-bold text-gray-300 mb-1.5 flex items-center justify-between">
                <span>Phone SMS OTP Verification</span>
                <span className="text-[10px] text-gray-400">Demo bypass: 123456</span>
              </label>
              <div className="flex items-center gap-2">
                <div className="relative flex-1 flex items-center">
                  <KeyRound className="w-3.5 h-3.5 text-amber-400 absolute left-3 pointer-events-none" />
                  <input
                    id="register-otp-input"
                    type="text"
                    maxLength={6}
                    value={otpCode}
                    onChange={(e) => setOtpCode(e.target.value.replace(/\D/g, ''))}
                    placeholder="Enter 6-digit OTP"
                    className="w-full pl-9 pr-3 py-2.5 bg-gray-950 border border-gray-800 rounded-xl text-xs text-amber-300 font-mono font-bold tracking-widest placeholder:font-sans placeholder:tracking-normal placeholder:font-normal placeholder-gray-500 focus:outline-none focus:border-amber-500 transition"
                    required
                  />
                </div>

                <button
                  id="register-send-otp-btn"
                  type="button"
                  disabled={isSendingOtp || otpCountdown > 0}
                  onClick={() => handleSendOtp('register')}
                  className="px-3.5 py-2.5 rounded-xl font-bold text-xs bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 shrink-0 transition disabled:opacity-50 disabled:pointer-events-none flex items-center gap-1"
                >
                  {isSendingOtp ? (
                    <div className="w-3.5 h-3.5 border-2 border-amber-400 border-t-transparent rounded-full animate-spin" />
                  ) : otpCountdown > 0 ? (
                    <span>{otpCountdown}s Resend</span>
                  ) : (
                    <span>Send OTP</span>
                  )}
                </button>
              </div>
            </div>

            {/* Set Password */}
            <div>
              <label className="text-[11px] font-bold text-gray-300 mb-1.5 block">
                Create Account Password (min. 6 chars)
              </label>
              <div className="relative flex items-center">
                <Lock className="w-3.5 h-3.5 text-amber-400 absolute left-3 pointer-events-none" />
                <input
                  id="register-password-input"
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Create password"
                  className="w-full pl-9 pr-10 py-2.5 bg-gray-950 border border-gray-800 rounded-xl text-xs text-white placeholder-gray-500 focus:outline-none focus:border-amber-500 transition"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 text-gray-400 hover:text-white"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Confirm Password */}
            <div>
              <label className="text-[11px] font-bold text-gray-300 mb-1.5 block">
                Confirm Password
              </label>
              <div className="relative flex items-center">
                <Lock className="w-3.5 h-3.5 text-amber-400 absolute left-3 pointer-events-none" />
                <input
                  id="register-confirm-password-input"
                  type={showPassword ? 'text' : 'password'}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Confirm password"
                  className="w-full pl-9 pr-3 py-2.5 bg-gray-950 border border-gray-800 rounded-xl text-xs text-white placeholder-gray-500 focus:outline-none focus:border-amber-500 transition"
                  required
                />
              </div>
            </div>

            {/* Referral / Invitation Code */}
            <div>
              <label className="text-[11px] font-bold text-gray-300 mb-1.5 flex items-center justify-between">
                <span>Invitation Code</span>
                <span className="text-[10px] text-amber-400 font-medium">₹68 Joining Bonus Active</span>
              </label>
              <input
                id="register-referral-input"
                type="text"
                value={referralCode}
                onChange={(e) => setReferralCode(e.target.value.toUpperCase())}
                placeholder="Enter referral code"
                className="w-full px-3 py-2.5 bg-gray-950 border border-gray-800 rounded-xl text-xs text-amber-300 font-mono focus:outline-none focus:border-amber-500 transition uppercase"
              />
            </div>

            {/* Terms Checkbox */}
            <div className="flex items-start gap-2 pt-1">
              <input
                id="register-terms-checkbox"
                type="checkbox"
                checked={agreeTerms}
                onChange={(e) => setAgreeTerms(e.target.checked)}
                className="mt-0.5 rounded text-amber-500 bg-gray-950 border-gray-800 focus:ring-0 cursor-pointer"
              />
              <label htmlFor="register-terms-checkbox" className="text-[11px] text-gray-400 cursor-pointer select-none">
                I am 18 years or older and accept the WinXbet VIP Fair Play &amp; Privacy Terms.
              </label>
            </div>

            <button
              id="submit-register-btn"
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-gradient-to-r from-red-600 via-rose-600 to-amber-500 hover:from-red-500 hover:to-amber-400 text-white font-black text-sm rounded-xl shadow-lg transition active:scale-[0.99] flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <span>Complete Registration &amp; Claim ₹68</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>
        )}

        {/* Divider */}
        <div className="relative flex items-center justify-center pt-1">
          <div className="border-t border-gray-800 w-full" />
          <span className="bg-gray-950 px-3 text-[10px] text-gray-500 uppercase tracking-wider shrink-0">
            Quick Instant Access
          </span>
          <div className="border-t border-gray-800 w-full" />
        </div>

        {/* Quick Instant Play Options: Google, Guest, Admin */}
        <div className="grid grid-cols-3 gap-2">
          <button
            id="login-google-btn"
            type="button"
            onClick={handleGoogleAuth}
            disabled={loading}
            className="flex items-center justify-center gap-1.5 py-2.5 px-2 rounded-xl bg-white text-gray-900 font-bold text-xs hover:bg-gray-100 transition shadow-md disabled:opacity-50"
            title="Sign in with Google"
          >
            <svg className="w-3.5 h-3.5 shrink-0" viewBox="0 0 24 24">
              <path
                fill="#4285F4"
                d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.8-2.4 3.65v3.03h3.88c2.27-2.09 3.66-5.17 3.66-9.12z"
              />
              <path
                fill="#34A853"
                d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.03c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.27v3.13C3.25 21.3 7.33 24 12 24z"
              />
              <path
                fill="#FBBC05"
                d="M5.28 14.29c-.25-.72-.38-1.49-.38-2.29s.13-1.57.38-2.29V6.57H1.27C.46 8.19 0 10.04 0 12s.46 3.81 1.27 5.43l4.01-3.14z"
              />
              <path
                fill="#EA4335"
                d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.25 2.7 1.27 6.57l4.01 3.14c.95-2.83 3.6-4.96 6.72-4.96z"
              />
            </svg>
            <span className="truncate">Google</span>
          </button>

          <button
            id="login-guest-btn"
            type="button"
            onClick={handleGuestAuth}
            disabled={loading}
            className="flex items-center justify-center gap-1.5 py-2.5 px-2 rounded-xl bg-gray-900 hover:bg-gray-800 text-amber-300 font-bold text-xs border border-amber-500/30 transition shadow-md disabled:opacity-50"
            title="Quick Guest Instant Play (+₹68 Bonus)"
          >
            <UserCheck className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span className="truncate">Guest</span>
          </button>

          <button
            id="login-admin-quick-btn"
            type="button"
            onClick={handleAdminAuth}
            disabled={loading}
            className="flex items-center justify-center gap-1 py-2.5 px-2 rounded-xl bg-gradient-to-r from-amber-500/20 to-red-500/20 hover:from-amber-500/30 hover:to-red-500/30 text-amber-300 font-black text-xs border border-amber-500/40 transition shadow-md disabled:opacity-50"
            title="Login as Platform Administrator (Demo)"
          >
            <Award className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <span className="truncate">Admin</span>
          </button>
        </div>
      </div>

      {/* Security & Download Source Code (.zip) Footer */}
      <div className="relative z-10 pt-4 pb-2 text-center space-y-2.5">
        <div className="flex items-center justify-center gap-4 text-[11px] text-gray-500">
          <div className="flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>256-Bit SSL</span>
          </div>
          <div className="flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5 text-amber-400" />
            <span>Provably Fair</span>
          </div>
          <div className="flex items-center gap-1">
            <Award className="w-3.5 h-3.5 text-blue-400" />
            <span>Fast UPI</span>
          </div>
        </div>

        {/* Direct Download App .zip package link */}
        <div className="flex items-center justify-center gap-2">
          <a
            href="/winxbet-app.zip"
            download="winxbet-app.zip"
            className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-gray-900 hover:bg-gray-800 border border-gray-800 hover:border-amber-500/40 text-[10px] text-gray-400 hover:text-amber-300 transition"
            title="Download full project source code as zip"
          >
            <Download className="w-3 h-3 text-amber-400" />
            <span>Download App Zip (.zip)</span>
          </a>
        </div>

        <p className="text-[10px] text-gray-600">
          Please play responsibly. Only adults aged 18+ are permitted to wager.
        </p>
      </div>
    </div>
  );
};
